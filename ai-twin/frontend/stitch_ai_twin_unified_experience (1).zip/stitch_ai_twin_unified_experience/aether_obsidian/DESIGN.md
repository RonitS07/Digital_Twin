# Design System Specification: The Executive Shadow

## 1. Overview & Creative North Star
**Creative North Star: The Digital Concierge**
The design system is built to evoke the feeling of a high-end, private executive suite at midnight. It moves away from the "cluttered dashboard" aesthetic of traditional SaaS, opting instead for a **Low-Cognitive Load Editorial** approach. We achieve this through intentional asymmetry, balanced negative space, and a "liquid" interface philosophy where elements feel like they are floating in a deep, sophisticated, and immersive dark environment.

This system rejects the rigid, boxy constraints of the web. By utilizing maximum corner radii (roundedness: 3) and avoiding structural lines, we create a fluid, organic experience that feels less like a tool and more like an extension of the user’s own mind in a focused, dark workspace.

---

## 2. Colors: The Midnight Fidelity
The color palette is rooted in a "Fidelity Dark" philosophy, shifting from flat blacks to a rich, premium depth. We use a sophisticated, muted neutral base (`neutral_color_hex`: `#777681`) as our foundation for surfaces and non-chromatic elements, ensuring the interface feels more like polished obsidian than standard charcoal.

### The "No-Line" Rule
**Strict Mandate:** Designers are prohibited from using 1px solid borders to define sections. 
*   **Correction:** Use tonal shifts. A section should be distinguished by moving from the base surface to a slightly lighter container tone or subtle depth shadow. 
*   **The "Ghost Border" Fallback:** If a container requires definition for accessibility, use the `outline-variant` at **15% opacity**. Never use a 100% opaque stroke.

### Surface Hierarchy & Nesting
Depth is communicated through "Tonal Stacking" within a dark-mode context.
1.  **Base:** Neutral Deep Background (`#777681`)
2.  **Sectioning:** Primary Tints (`#6760fd`) used at very low opacities to create soft "glows" of color within containers.
3.  **Accent Layers:** Secondary (`#7170b6`) and Tertiary (`#a54100`) tones for highlights, badges, and decorative elements.

### Signature Textures (Glass & Gradients)
AI-driven interactions must feel "alive" against the dark backdrop. 
*   **The AI Pulse:** Use a linear gradient from `primary` (#6760fd) to `secondary` (#7170b6) at 45 degrees for active states.
*   **Glassmorphism:** For overlays, use dark surface containers at 60% opacity with a `40px` backdrop blur. This ensures the "executive assistant" feels present and clear without breaking the immersion.

---

## 3. Typography: Editorial Authority
We utilize a dual-typeface system to balance technical precision with executive elegance.

*   **Display & Headlines (Manrope):** Chosen for its geometric modernism and wide aperture. It feels authoritative yet approachable. 
    *   *Usage:* Use `display-lg` for welcome states and `headline-md` for section titles. Keep tracking (letter-spacing) at -2% for headlines to create a "tight" editorial feel.
*   **Interface & Body (Inter):** The industry standard for readability. 
    *   *Usage:* Use `body-md` for general assistant responses. Use `label-sm` in ALL CAPS with +5% tracking for metadata to create a "technical" contrast against the soft UI.

---

## 4. Elevation & Depth: Tonal Layering
In dark mode, we rely on soft light physics and a compact-to-normal spacing rhythm.

*   **The Layering Principle:** Instead of heavy shadows, use subtle value shifts. Placing a slightly lighter or more saturated element inside a dark neutral area creates a "soft lift."
*   **Ambient Glows:** For floating elements (like the AI input bar), use a multi-layered soft glow instead of a traditional shadow:
    *   `0px 10px 40px rgba(119, 118, 129, 0.3)` (Neutral Tinted Depth).
    *   Followed by a subtle aura: `0px 0px 20px rgba(103, 96, 253, 0.1)` (Primary Tint).
*   **Intentional Asymmetry:** Avoid centering everything. Align secondary information to the far right or left to create "visual tension" that mimics high-end print magazines.

---

## 5. Components

### The Intelligence Input (Search/Command Bar)
*   **Style:** Pill-shaped (roundedness: 3) corners. 
*   **Fill:** Deep dark surface with a 15% opacity `primary` glow on focus.
*   **Interaction:** When the user types, the background should subtly transition to a soft glassmorphism blur.

### Buttons: The Tactile Touch
*   **Primary:** `primary` (#6760fd) fill with appropriate contrast text. Pill-shaped (roundedness: 3). No border.
*   **Secondary:** Ghost style. No fill. `outline-variant` at 20% opacity.
*   **AI Action:** A gradient-fill button using `primary` to `tertiary` (#a54100). This is reserved *only* for "Generate" or "Analyze" actions.

### Cards & Lists: The Separation of Thought
*   **The Rule:** No dividers. 
*   **Execution:** Use normal spacing (spacing: 2) between list items. If items must be grouped, use a rounded "pill" container to encapsulate the group.

### The "AI Presence" Indicator
*   A small, 8px circular chip using `secondary` (#7170b6) with a soft 12px blur glow. It should sit in the top-right of containers to indicate the "Twin" is currently processing or active.

---

## 6. Do’s and Don’ts

### Do:
*   **Do** use consistent whitespace. The system utilizes a normal spacing scale (2) to maintain a balance between density and elegance.
*   **Do** take advantage of the dark color mode to create a focused, low-glare environment for high-end tasks.
*   **Do** use maximum corner radii (roundedness: 3) for all main containers to maintain the "Soft" aesthetic.

### Don’t:
*   **Don’t** use pure white for text; use high-contrast versions of the neutral or primary palette to maintain the "Midnight Fidelity" feel.
*   **Don’t** use 1px dividers or "grid lines." The UI should feel like a single, seamless fluid surface.
*   **Don’t** use standard "Blue" links. Use `secondary` (#7170b6) with a subtle underline-offset of 4px.
*   **Don’t** crowd the interface. Maintain the "Low-Cognitive Load" priority by hiding secondary actions in drawers.